<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>UPDATING</title>
<link rel="shortcut icon" href="..\Images\logo.jpeg" type="image/x-icon" />
<style>
        body,html{
            margin: 0;
            padding: 0;
        }
        *{

            font-family: cursive;
        }
        .box{
            display: flex;
            flex-wrap: wrap;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }
        h2{
            font-size: 30px;
            color: blue;
        }
        
        img{
            height: 40%;
            width: 40%;           
        }
        p{
        	font-weight: bolder;
        	font-size: 20px;
        }
    </style>
</head>
<body>
<div class="box">
<h2>The Contents are Updating!!! Stay Tuned :)</h2>
<div class="img">
<img src="..\Images\updating.png" alt="">
</div>
<p>In case of any problem / help / suggestions mail us at ietapna@gmail.com</p>
</div>


</body>
</html>