<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="..\CSS\syllabus.css">
<title>MCA Syllabus</title>
<link rel="shortcut icon" href="..\Images\logo.jpeg" type="image/x-icon" />
</head>
<body>
<div id="container">
<div class="box">
<div class="topbox">
<h2>Syllabus for Master of Computer Applications</h2>
</div>
<div class="downbox">
<table border="3">
<thead>
<tr>
<th>Topic Name</th>
<th>View</th>
<th>Download</th>
</tr>
</thead>
<tbody>
<tr>
<td> MCA 2 Year Syllabus </td>
<td><a href="https://drive.google.com/file/d/1QOSTkfeTcqTDojA0DT1qkmwXS4_6U-my/view?usp=sharing" target="_blank">View</a></td>
<td><a href="https://drive.google.com/uc?export=download&id=1QOSTkfeTcqTDojA0DT1qkmwXS4_6U-my" target="_blank">Download</a></td>
</tr>
<tr>
<td> Full Syllabus </td>
<td><a href="https://drive.google.com/file/d/1S92mhLbgYuLaIbLK0xDjEJzmKvld6zRK/view?usp=sharing" target="_blank">View</a></td>
<td><a href="https://drive.google.com/uc?export=download&id=1S92mhLbgYuLaIbLK0xDjEJzmKvld6zRK" target="_blank">Download</a></td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
</body>
</html>