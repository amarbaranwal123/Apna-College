<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="..\CSS\notes.css">
<title>Stream Wise Notes</title>
<link rel="shortcut icon" href="..\Images\logo.jpeg" type="image/x-icon" />

</head>
<body>
<div class="heading">
<h1 id="streamheading" data-aos="fade-down" data-aos-duration="1500">Select Your Stream for Notes</h1>
</div>
<div id="container">
<div class="box" id="box1" data-aos="fade-up" data-aos-duration="1500">
<div class="leftbox">
<h3>Master of<br> Computer <br>Applications <br>(MCA)</h3>
</div>
<div class="rightbox">
<p>Download all notes of this stream.<br><br>AVAILABLE!!<br><br></p>
<button class="btn" onclick="window.location.href='../PHP/sem.php'">Download</button>
</div>
</div>
<div class="box" id="box2" data-aos="fade-up" data-aos-duration="1500">
<div class="leftbox">
<h3>Information<br> Technology<br>(IT)</h3>
</div>
<div class="rightbox">
<p>Download all notes of this stream.<br><br> Content will be updated soon<br><br></p>
<button class="btn" onclick="window.location.href='../PHP/update.php'">Download</button>



</div>
</div>
<div class="box" id="box2" data-aos="fade-up" data-aos-duration="1500">
<div class="leftbox">
<h3>Computer<br> Science & <br>Engineering <br>(CSE)</h3>
</div>
<div class="rightbox">
<p>Download all notes of this stream.<br><br> Content will be updated soon<br><br></p>
<button class="btn" onclick="window.location.href='../PHP/update.php'">Download</button>



</div>
</div>
</div>
</body>
</html>