<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="..\CSS\paper.css">
<title>Questions Papers</title>
<link rel="shortcut icon" href="..\Images\logo.jpeg" type="image/x-icon" />
</head>
<body>
<div class="heading">
	<h1>Select Your Stream for Examination Papers</h1>
</div>
<div id="container">
<div class="box" id="box1">
<div class="leftbox">
<h3>Master of Computer Applications (MCA)</h3>
</div>
<div class="rightbox">
<p>Download Question Paper of this Stream</p>

<button class="btn" onclick="window.location.href='../PHP/papers.php'">Download</button>
</div>
</div>
</div>
</body>
</html>